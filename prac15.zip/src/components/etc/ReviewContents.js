import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import cs from './customerReview.module.scss'

import React from 'react'

export default function ReviewContents() {
  return (
    <div>
      <Swiper>
        dd
      </Swiper>
    </div>
  )
}
