import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import ReviewContents from './ReviewContents';
import cs from './customerReview.module.scss'


export default function CustomerReviews() {
  return (
    <div className={cs.swiperContainer}>
      <ReviewContents></ReviewContents>
      <Swiper
        spaceBetween={2} // 슬라이드 간 간격
        slidesPerView={5.5} // 한 화면에 보여질 슬라이드 개수 자동 조정
        loop={false} // 루프 설정
        modules={[Navigation, Pagination, Autoplay]}
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        navigation={true} // 기본 네비게이션 버튼 활성화
        pagination={{ clickable: true }} // 페이지네이션 활성화
      >
        {/* 사진 슬라이드 */}
        <SwiperSlide className={cs.swiperSlide}>
        
        </SwiperSlide>
        <SwiperSlide className={cs.swiperSlide}>
   
        </SwiperSlide>
        <SwiperSlide className={cs.swiperSlide}>
          
        </SwiperSlide>
        <SwiperSlide className={cs.swiperSlide}>
          
        </SwiperSlide>
        <SwiperSlide className={cs.swiperSlide}>
          <img src="https://via.placeholder.com/400x200?text=5" alt="Slide 5" />
        </SwiperSlide>
        <SwiperSlide className={`${cs.swiperSlide} ${cs.halfVisibleSlide}`}>
          <img src="https://via.placeholder.com/400x200?text=6" alt="Slide 6" />
        </SwiperSlide>
      </Swiper>
    </div>
  );
}
