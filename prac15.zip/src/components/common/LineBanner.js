import React from 'react'

export default function Linebanner() {
  return (
    <div>Linebanner</div>
  )
}
