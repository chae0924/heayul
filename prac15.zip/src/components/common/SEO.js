import React from 'react'

export default function SEO() {
  return (
    <div>SEO</div>
  )
}
