import React from 'react'
import prdcard from './ProductCard.module.scss'

export default function ProductCard() {
  return (
    <div>ProductCard</div>
  )
}
